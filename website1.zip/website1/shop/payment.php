<style>
    .pay{
        background: #f2bcc0;
        text-align: center;
        /* left: 200px; */
        padding: 10px;
        width: 50%;
        display: block;
        margin-left: auto;
        margin-right: auto;
        font-size: 20px;
        height: auto;
    }
    .pay .the_a a{
        padding: 10px 10px;
        border-radius: 10px;
        color: #fff;
        background: red;
    }
    .pay .the_a{
        margin: 15px 0px;
    }
    .pay .the_a a:hover{
        background: #605656;
    }
    a.pre
    {
        color: 12px;
        background: red;
        padding: 5px;
        border-radius: 10px;
        /* margin: 5px; */
        color: #fff;
    }
    a.pre:hover{
        background: #605656;
    }
</style>
<?php
	include "inc/header.php";
	// include "inc/slider.php";
?>
<?php
	$login_check = Session::get('customer_login');
    if($login_check == false)
    {
        header('Location: login.php');
    }
?>
 <div class="main">
    <div class="content">
    	<div class="section group">
        <div class="content_top">
    		<div class="heading">
    		<h3>Payment Method</h3>
    		</div>
            <div class="clear"></div>
            <div class="pay">
                <h3>Choose Your Method Payment</h3>
                <div class="the_a">
                    <a href="offpayment.php">Offline Payment</a>
                    <a href="onpayment.php">Online Payment</a>
                </div>
                <a href="cart.php" class="pre"><<=Previous</a>
            </div>
    	</div>
        </div>
    </div>
</div>
<?php
	include "inc/footer.php";
?>