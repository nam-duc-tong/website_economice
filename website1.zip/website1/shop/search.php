<?php
	include "inc/header.php";
	// include "inc/slider.php";
?>

 <div class="main">
    <div class="content">
	<?php

		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$tukhoa = $_POST['tukhoa'];
			$search_product = $product->search_product($tukhoa);
		}

	?>
    	<div class="content_top">
    		<div class="heading">
			<h3>Tu khoa tim kiem: <?php echo $tukhoa?></h3>
    		</div>
    		<div class="clear"></div>
    	</div>
		<div class="section group">
		<?php
				if($search_product)
				{
					while($result= $search_product->fetch_assoc())
						{
		?>
	      
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="preview-3.php"><img src="admin/upload/<?php echo $result['image']?>" alt=""  width="160px" height="160px"/></a>
					 <h2><?php echo $result['productName']?></h2>
					 <p><span class="price"><?php echo $result['product_desc']?></p>
					 <p><span><?php echo number_format($result['price'], 0, '', '.').' VND';?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?php echo $result['productId']?>" class="details">Details</a></span></div>
				</div>
				<?php
								
							}
						}
						?>		
		</div>
    </div>
 </div>
<?php
	include "inc/footer.php";
?>