<div class="header_bottom">
		<div class="header_bottom_left">
			<div class="section group">
				<?php
					$getLastIphone = $product->getLastestIphone();
					if($getLastIphone)
					{
						while($resultIphone = $getLastIphone->fetch_assoc())
						{
				?>
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						 <a href="details.php"> <img src="admin/upload/<?php echo $resultIphone['image']?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
						<h2>IPHONE</h2>
						<p><?php echo $fm->textShorten($resultIphone['product_desc'],30)?></p>
						<div class="button"><span><a href="details.php?proId=<?php echo $resultIphone['productId']?>">Add to cart</a></span></div>
				   </div>
			   </div>	
			   <?php
					}
				}
				?>		
				<?php
					$getLastSamsung = $product->getLastestSamsung();
					if($getLastSamsung)
					{
						while($resultSamsung = $getLastSamsung->fetch_assoc())
						{
				?>
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						  <a href="details.php"><img src="admin/upload/<?php echo $resultSamsung['image']?>" alt="" /></a>
					</div>
					<div class="text list_2_of_1">
						  <h2>SAMSUNG</h2>
						  <p><?php echo $fm->textShorten($resultSamsung['product_desc'],30)?></p>
						  <div class="button"><span><a href="details.php?proId=<?php echo $resultSamsung['productId']?>">Add to cart</a></span></div>
					</div>
				</div>
				<?php
					}
				}
				?>	
			</div>
			<div class="section group">
			<?php
					$getLastOppo = $product->getLastestOppo();
					if($getLastOppo)
					{
						while($resultOppo = $getLastOppo->fetch_assoc())
						{
			?>
			
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						 <a href="details.php"> <img src="admin/upload/<?php echo $resultOppo['image']?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
						<h2>OPPO</h2>
						<p><?php echo $fm->textShorten($resultOppo['product_desc'],30)?></p>
						<div class="button"><span><a href="details.php?proId=<?php echo $resultOppo['productId']?>">Add to cart</a></span></div>
				   </div>
			   </div>	
			   <?php
					}
				}
				?>	
				<?php
					$getLastestVivo = $product->getLastestVivo();
					if($getLastestVivo)
					{
						while($resultVivo = $getLastestVivo->fetch_assoc())
						{
				?>
				
				<div class="listview_1_of_2 images_1_of_2">
					<div class="listimg listimg_2_of_1">
						  <a href="details.php"><img src="admin/upload/<?php echo $resultVivo['image']?>" alt="" /></a>
					</div>
					<div class="text list_2_of_1">
						  <h2>VIVO</h2>
						  <p><?php echo $fm->textShorten($resultVivo['product_desc'],30)?></p>
						  <div class="button"><span><a href="details.php?proId=<?php echo $resultVivo['productId']?>">Add to cart</a></span></div>
					</div>
				</div>
				<?php
					}
				}
				?>	
			</div>
		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<?php
							$get_slider =$product->show_slider();
							if($get_slider)
							{
								while($result_slider = $get_slider->fetch_assoc())
								{
						?>
								<li><img src="admin/upload/<?php echo $result_slider['slider_image']?>" alt="<?php echo $result_slider['sliderName']?>"/></li>
						<?php
								}
							}
						?>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>