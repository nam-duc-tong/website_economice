<?php
	include "inc/header.php";
	include "inc/slider.php";
?>
 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">

                    <h3 style="color: red;background: yellow;">Page doesn't found</h3>

			</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
<?php
	include "inc/footer.php";
?>
