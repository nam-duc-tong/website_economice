<?php
	include "inc/header.php";
	// include "inc/slider.php";
?>
<?php
	  if(!isset($_GET['proId']) || $_GET['proId'] == NULL)
	  {
		//   echo "<script>window.location = '404.php'</script>";
	  }
	  else{
		  $id = $_GET['proId'];
	  }
	  if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit']))
	  {
		$quantity = $_POST['quantity'];
		$addtoCart = $ct->add_to_cart($quantity, $id);
	  }
	  if(isset($_POST['binhluan_submit']))
	  {
		$binhluan_insert = $cs->insert_binhluan();
	  }
?>
 <div class="main">
    <div class="content">
    	<div class="section group">
			<?php
				$product_details = $product->getproductdetails($id);
				if(isset($product_details))
				{
					while($result_product_list = $product_details->fetch_assoc())
					{
			?>
				<div class="cont-desc span_1_of_2">				
					<div class="grid images_3_of_2">
						<img src="admin/upload/<?php echo $result_product_list['image']?>" alt="" style="height: auto" />
					</div>
				<div class="desc span_3_of_2">
					<h2><?php echo $result_product_list['productName']?></h2>
					<p><?php echo $result_product_list['product_desc']?></p>					
					<div class="price">
						<p>Price: <span><?php echo number_format($result_product_list['price'], 0, '', '.').' VND';?></span></p>
						<p>Category: <span><?php echo $result_product_list['catName']?></span></p>
						<p>Brand:<span><?php echo $result_product_list['brandName']?></span></p>
					</div>
				<div class="add-cart">
					<form action="" method="post">
						<input type="number" class="buyfield" name="quantity" min="1" value="1"/> 
						<input type="submit" class="buysubmit" name="submit" value="Buy Now"/>
						<?php
							if(isset($addtoCart))
							{
								echo "<br><span style='color: red;font-size: 18px;'>Thêm sản phẩm thành công</span>";
							}
						?>
					</form>				
				</div>
				
			</div>
			<div class="product-desc">
			<h2>Product Details</h2>
			<p><?php echo $result_product_list['product_desc']?></p>
		<?php
					}
				}
		?>
		</div>
	
	</div>
				<div class="rightsidebar span_3_of_1">
					<h2>CATEGORIES</h2>
					<ul>
						<?php
							$cat_list = $cat->show_category_frontend();
							if(isset($cat_list))
							{
								while($result_cat = $cat_list->fetch_assoc())
								{
						?>
							<li><a href="productbycat.php?catId=<?php echo $result_cat['catId']?>"><?php echo $result_cat['catName']?></a></li>
						<?php
								}
							}
						?>
					</ul>
									
 				</div>

 		</div>
		<div class="binhluan" style="width: 50%;">
			<form action="" method="POST">
			<h5>Y kien ca nhan</h5>
			<?php
				if(isset($binhluan_insert))
				{
					echo $binhluan_insert;
				}
			?>
			<p><input type="hidden" value="<?php echo $id;?>" name="product_id_binhluan"></p>
			<input type="text" placeholder="Dien ten" class="form-control" name="tennguoibinhluan" style="width: 50%"><br>
			<textarea rows="5" style="resize: none;" name="binhluan" class="form-control" placeholder="Binh luan ..."></textarea>
			<p style="padding-top: 25px;"><input type="submit" name="binhluan_submit" class="btn btn-success" value="Gửi bình luận"></p>
			</form>
		</div>
 	</div>
<?php
	include "inc/footer.php";
?>