<?php
	include "inc/header.php";
	// include "inc/slider.php";
?>
<style>
    .the_p{
        background: yellow;
        padding: 10px;
    }
    .the_p p{
        text-align: center;
    }
</style>
<?php
	  if(isset($_GET['orderid']) && $_GET['orderid'] == 'order')
	  {
            $customer_id = Session::get('customer_id');
            $insertOrder = $ct->insertOrder($customer_id);
            // $delcart = $ct->del_all_data_cart();
            // echo $insertOrder;
            header('Location:success.php');
      }
?>
<form action="" method="POST">
 <div class="main">
    <div class="content">
    	<div class="section group">
            <h2 style="color: red; text-align: center;">Success Order</h2>
            <?php
                $customer_id = Session::get('customer_id');
                $get_amount = $ct->getAmountPrice($customer_id);
                if($get_amount)
                {
                    $amount = 0;
                    while($result = $get_amount->fetch_assoc())
                    {
                        $price = $result['price'];
                        $amount += $price;
                    }
                }
            ?>
            <div class="the_p">
                <p class="success_note">Total Price You Have Bought From My  Website:
                    <?php
                        if(isset($amount))
                        {
                            echo number_format($amount+$amount*0.1, 0, '', '.').' VND';
                        }   
                        else
                        {
                            echo '0 VND';
                        }
                    ?></p>
                <p>We will contact or soon as possible. Please see your order details here <a href="orderdetails.php">Click Here</a></p>
            </div>
        </div>
    </div>
 	</div>
</form>
<?php
	include "inc/footer.php";
?>