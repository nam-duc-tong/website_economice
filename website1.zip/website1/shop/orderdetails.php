<?php
	include "inc/header.php";
	// include "inc/slider.php";
?>
<?php
    $login_check = Session::get('customer_id');
    if($login_check == false)
    {
        header('Location:login.php');
    }
?>
<style>
	.cartpage h2{
		width: 100%;
	}
</style>
 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2 style="color: #6C6C6C; font-size: 25px; padding-bottom: 10px;" >Your Order Details</h2>
					<?php
						if(isset($update_quantity_cart))
						{
							echo $update_quantity_cart;
						}
						if(isset($delcart))
						{
							echo $delcart;
						}
					?>
						<table class="tblone">
							<tr>
                                <th>ID</th>
								<th width="20%">Product Name</th>
								<th width="10%">Image</th>
								<th width="15%">Price</th>
								<th width="25%">Quantity</th>
                                <th>Date</th>
								<th width="10%">Status</th>
							</tr>
							<?php
                                $customer_id = Session::get('customer_id');
								$get_cart_ordered = $ct->get_cart_ordered($customer_id);
								if($get_cart_ordered)
								{
									$qty = 0;
                                    $i=0;
									while($result = $get_cart_ordered->fetch_assoc())
									{
                                        $i++;
							?>
								<tr>
                                    <td><?php echo $i;?></td>
									<td><?php echo $result['productName']?></td>
									<td><img src="admin/upload/<?php echo $result['image']?>" alt=""/></td>
									<td><?php echo number_format($result['price'], 0, '', '.').' VND';?></td>
									<td>
										<?php echo $result['quantity']?>
									</td>
                                    <td><?php echo $fm->formatDate($result['data_order'])?></td>
                                    <td>
                                        <?php
                                            if($result['status'] == 0)
                                            {
                                                echo "Đang xử lý";
                                            } 
                                            elseif($result['status'] == 1){
                                                echo "Đã xử lý";
                                            }
                                        ?>
                                    </td>
								</tr>
							<?php
									
									}		
								}		
							?>
							
						</table>
    	</div>  	
        <div class="shopping">
            <div class="shopleft">
                <a href="index.php"><img src="images/shop.png" alt=""></a>
            </div>
        </div>
       <div class="clear"></div>
    </div>
 </div>
<?php
	include "inc/footer.php";
?>
