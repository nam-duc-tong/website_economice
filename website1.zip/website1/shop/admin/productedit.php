<?php include_once 'inc/header.php';?>
<?php include_once 'inc/sidebar.php';?>
<?php 
    require_once '../classes/brand.php';
    require_once '../classes/category.php';
    require_once '../classes/product.php';
?>
<?php
    $product = new product();
    if(!isset($_GET['productId']) || $_GET['productId'] == NULL)
    {
        echo "<script>window.location = 'productlist.php'</script>";
    }
    else{
        $id = $_GET['productId'];
    }
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit']))
    {
        $updateProduct = $product->update_product($_POST,$_FILES,$id);
    }
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Sửa Sản Phẩm</h2>
        <div class="block">       
            <?php
                if(isset($updateProduct))
                {
                    echo $updateProduct;
                }
            ?>        
        <?php
            $get_product_by_id = $product->getproductbyId($id);
            if($get_product_by_id)
            {
                while($result_pro = $get_product_by_id->fetch_assoc())
                {

        ?>
         <form action="" method="post" enctype="multipart/form-data">
            <table class="form">
               
                <tr>
                    <td>
                        <label>Tên</label>
                    </td>
                    <td>
                        <input type="text" name="productName" placeholder="Enter Product Name..." value= "<?php echo $result_pro['productName'];?>" class="medium" />
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Danh Mục</label>
                    </td>
                    <td>
                        <select id="select" name="category">
                            <option>Chọn danh mục</option>
                            <?php
                                $cat = new category();
                                $catlist = $cat->show_category();

                                if($catlist)
                                {
                                    while($result = $catlist->fetch_assoc())
                                    {
                            ?>
                            <option 
                            <?php
                                if($result['catId'] == $result_pro['catId'])
                                {
                                    echo 'Selected';
                                }
                            ?>
                            value="<?php echo $result['catId'];?>"><?php echo $result['catName'];?></option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Thương Hiệu</label>
                    </td>
                    <td>
                        <select id="select" name="brand">
                            <option>Chọn Thương Hiệu</option>
                           <?php
                                $brand = new Brand();
                                $brandlist = $brand->show_brand();
                                if($brandlist)
                                {
                                    while($result = $brandlist->fetch_assoc())
                                    {
                           ?>
                                <option 
                                <?php
                                    if($result['brandId']==$result_pro['brandId'])
                                    {
                                        echo "Selected";
                                    }
                                ?>
                                value="<?php echo $result['brandId']?>"><?php echo $result['brandName']?></option>
                           <?php
                                 }
                            }
                           ?>
                        </select>
                    </td>
                </tr>
				
				 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Mô Tả</label>
                    </td>
                    <td>
                        <textarea name="product_desc" class="tinymce"> <?php echo $result_pro['product_desc']?></textarea>
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Giá</label>
                    </td>
                    <td>
                        <input type="text" name="price" placeholder="Nhập giá..." class="medium"  value="<?php echo $result_pro['price']?>"/>
                    </td>
                </tr>
            
                <tr>
                    <td>
                        <label>Tải Ảnh Lên</label>
                    </td>
                    <td>
                        <img src="upload/<?php echo $result_pro['image']?>" alt=""><br>
                        <input type="file" name = "image" />
                    </td>
                </tr>
				
				<tr>
                    <td>
                        <label>Loại Sản Phẩm</label>
                    </td>
                    <td>
                        <select id="select" name="type">
                            <option>Chọn Loại Sản Phẩm</option>
                            <?php
                                if($result_pro['type']==0)
                                {
                                    ?>
                                    <option selected value="0">Không nổi bật</option>
                                    <option value="1">Nổi bật</option>
                                <?php
                                }
                                else{
                                    ?>
                                    <option  value="0">Không nổi bật</option>
                                    <option selected value="1">Nổi bật</option>
                            <?php
                                }
                            ?>
                        </select>
                    </td>
                </tr>

				<tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" value="Update" />
                    </td>
                </tr>
            </table>
            </form>
            <?php
                }   
            } 
            ?>
        </div>
    </div>
</div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php';?>


